
public class pixel {
	public static int size = 3;
}
