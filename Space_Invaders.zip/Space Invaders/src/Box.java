public class Box extends Object {
	int ample, alt;
	
	Box(int x, int y){
		super(x,y);
		this.x=x; this.y=y; 
	}
	
}
