public class Object {
	
	int x,y;
	static final int pixel = 3;
	
	Object(int x, int y){
		this.x=x; this.y=y; 
	}
	
}
